package com.avitam.bankloanapplication.model;

public enum LoanType {
    AUTOMOBILE,STUDENT,MORTGAGE,PERSONAL,BUSINESS,SHOP
}
