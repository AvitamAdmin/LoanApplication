package com.avitam.bankloanapplication.model.dto;

import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class NotificationDto extends CommonDto  {

    private String text;


}
