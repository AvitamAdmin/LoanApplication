package com.avitam.bankloanapplication.service;

import com.avitam.bankloanapplication.model.dto.KYCWsDto;

public interface KycService {
    KYCWsDto handelEdit(KYCWsDto request);
}
