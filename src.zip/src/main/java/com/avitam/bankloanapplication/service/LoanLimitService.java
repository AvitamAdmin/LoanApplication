package com.avitam.bankloanapplication.service;

import com.avitam.bankloanapplication.model.dto.LoanLimitWsDto;

public interface LoanLimitService {

    LoanLimitWsDto editLoanLimit(LoanLimitWsDto request);
}
