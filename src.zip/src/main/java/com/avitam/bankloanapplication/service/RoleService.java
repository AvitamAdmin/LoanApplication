package com.avitam.bankloanapplication.service;

import com.avitam.bankloanapplication.model.dto.RoleWsDto;

public interface RoleService {

    RoleWsDto createRole(RoleWsDto request);
}
