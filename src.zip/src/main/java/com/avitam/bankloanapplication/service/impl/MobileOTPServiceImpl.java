package com.avitam.bankloanapplication.service.impl;

import com.avitam.bankloanapplication.model.dto.UserDto;
import com.avitam.bankloanapplication.service.MobileOTPService;
import org.springframework.stereotype.Service;

@Service
public class MobileOTPServiceImpl implements MobileOTPService {
    @Override
    public UserDto sendOtp(UserDto userDto) {
        return null;
    }

    @Override
    public UserDto validateOtp(UserDto userDto) {
        return null;
    }

    @Override
    public UserDto saveUsername(UserDto userDto) {
        return null;
    }
}
