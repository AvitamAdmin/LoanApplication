package com.avitam.bankloanapplication.service;

import com.avitam.bankloanapplication.model.dto.WebsiteSettingWsDto;

public interface WebsiteSettingService {
    WebsiteSettingWsDto handleEdit(WebsiteSettingWsDto request);
}
