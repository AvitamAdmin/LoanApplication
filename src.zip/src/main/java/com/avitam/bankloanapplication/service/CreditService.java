package com.avitam.bankloanapplication.service;

import com.avitam.bankloanapplication.model.dto.CreditWsDto;

public interface CreditService {
    CreditWsDto handelEdit(CreditWsDto request);
}
