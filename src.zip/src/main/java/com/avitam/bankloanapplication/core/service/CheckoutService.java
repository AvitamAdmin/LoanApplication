package com.avitam.bankloanapplication.core.service;

public interface CheckoutService {

   //void saveCheckout(TestResult testResult);

   // List<TestResult> findAllBySessionIdAndTestName(String sessionId, String testName);
}
