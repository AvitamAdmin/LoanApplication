package com.avitam.bankloanapplication.core.service;

import com.avitam.bankloanapplication.model.entity.User;

public interface CoreService {
    User getCurrentUser();
}
