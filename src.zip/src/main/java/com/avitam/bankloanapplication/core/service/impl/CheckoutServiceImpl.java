package com.avitam.bankloanapplication.core.service.impl;

import com.avitam.bankloanapplication.core.service.CheckoutService;
import org.springframework.stereotype.Service;

@Service
public class CheckoutServiceImpl implements CheckoutService {


    }


